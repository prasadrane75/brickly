-- AlterTable
ALTER TABLE "Property" ADD COLUMN     "squareFeet" INTEGER;
