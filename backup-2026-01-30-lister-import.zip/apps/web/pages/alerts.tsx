export default function AlertsPage() {
  return (
    <main>
      <h1 className="section-title">Alerts</h1>
      <div className="card">
        <p className="muted">No alerts yet.</p>
      </div>
    </main>
  );
}
