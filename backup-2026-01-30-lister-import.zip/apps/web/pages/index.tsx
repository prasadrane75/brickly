export default function HomePage() {
  return (
    <main className="home-hero">
      <div className="home-hero-content">
        <h1>Brickly</h1>
        <p>Discover and invest in fractional properties.</p>
      </div>
    </main>
  );
}
